#include <stdio.h>
#include <Windows.h>

int main()
{
    printf("Hi, my name is ��С��\n");
    Sleep(3 * 1000);

    return 0;
}